/*
 * Kathleen Fisher, Robert Gruber
 * AT&T Labs Research
 */

#ifndef __PB_INT_IMPL_H__
#define __PB_INT_IMPL_H__

#ifndef __PADS_IMPL_H__
#error Pb_int-impl.h is intended to be included from pads-impl.h, do not include it directly
#endif

/* ================================================================================
 * READ
 */


/* ================================================================================
 * WRITE
 */

#endif  /*  __PB_INT_IMPL_H__   */
