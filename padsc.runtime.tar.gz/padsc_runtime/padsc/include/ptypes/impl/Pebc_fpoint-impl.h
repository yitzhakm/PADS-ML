/*
 * Kathleen Fisher, Robert Gruber
 * AT&T Labs Research
 */

#ifndef __PEBC_FPOINT_IMPL_H__
#define __PEBC_FPOINT_IMPL_H__

#ifndef __PADS_IMPL_H__
#error Pebc_fpoint-impl.h is intended to be included from pads-impl.h, do not include it directly
#endif

/* ================================================================================
 * READ
 */


/* ================================================================================
 * WRITE
 */

#endif  /*  __PEBC_FPOINT_IMPL_H__   */
