/*
 * Kathleen Fisher, Robert Gruber
 * AT&T Labs Research
 */

#ifndef __PSB_FPOINT_IMPL_H__
#define __PSB_FPOINT_IMPL_H__

#ifndef __PADS_IMPL_H__
#error Psb_fpoint-impl.h is intended to be included from pads-impl.h, do not include it directly
#endif

/* ================================================================================
 * READ
 */


/* ================================================================================
 * WRITE
 */

#endif  /*  __PSB_FPOINT_IMPL_H__   */
